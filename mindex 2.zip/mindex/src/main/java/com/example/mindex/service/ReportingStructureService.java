package com.example.mindex.service;

import com.example.mindex.data.Employee;
import com.example.mindex.data.ReportingStructure;

public interface ReportingStructureService {
    ReportingStructure create(Employee employee);
}
